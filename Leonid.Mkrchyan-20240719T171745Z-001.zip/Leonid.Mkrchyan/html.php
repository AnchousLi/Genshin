<!DOCTYPE html>
<html lang="en">
<head>
   <link rel="stylesheet" href="style.css">
    <title>Genshin Impact</title>
</head>
<body>
    <div class="genshin">
        <img src="https://upload.wikimedia.org/wikipedia/ru/thumb/5/5d/Genshin_Impact_logo.svg/1024px-Genshin_Impact_logo.svg.png?20231028060936    " alt="">
    </div>
   
    <a class="download" href="https://sg-public-api.hoyoverse.com/event/download_porter/trace/ys_global/genshinimpactpc/default?url=https%3A%2F%2Fact.hoyoverse.com%2Fpuzzle%2Fhk4e%2Fpz_MbGXG2vgVO%2Findex.html%3Fpz_plat%3Dpc%26lang%3Den-us%26game_biz%3Dhk4e_global%26bridge_name%3Dpz_MbGXG2vgVO    ">
        <span class="dan">Download</span>
    </a>
    <div class="youtube">
    <iframe width="1120" height="630" src="https://www.youtube.com/embed/5vEpQZHKz1E?si=c0dXMk_HcDrzr1aX" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
    </div>  

    <DIV class="all">
<div class="monli">
    <div class="monshtad">
        <a href="monshtad.php"><h1> Monshtad</h1></a>
    </div>

    <div class="li">
       <a href="li%20ue.php"><h1>Li Yue</h1></a>
    </div>
</div>
<div class="insu">
    <div class="inadz">
        <a href="inadzuma.php"><h1>Inadzuma</h1></a>
    </div>
    <div class="sumeru">
        <a href="sumeru.php"><h1>Sumeru</h1></a>
    </div>
</div>
    <div class="fontein">
        <a href="fontine.php"><h1>Fontein</h1></a>
    </div>
</DIV>
<div class="hder">
            <div class="logo"> <img class="img" src="https://upload.wikimedia.org/wikipedia/ru/thumb/5/5d/Genshin_Impact_logo.svg/1024px-Genshin_Impact_logo.svg.png?20231028060936    "></div>
           
            <ul>
                <li><a href="html.php">Home</a> </li>
                <li><a href="monshtad.php">Monshtad</a> </li>
                <li><a href="li%20ue.php">Li Yue</a></li>
                <li><a href="inadzuma.php">Inadzuma</a> </li>
                <li><a href="sumeru.php">Sumeru</a> </li>
                <li><a href="fontine.php"> Fontein</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="admin/index.php">Admin</a></li>
            </ul>
        </div>

</body>
</html>