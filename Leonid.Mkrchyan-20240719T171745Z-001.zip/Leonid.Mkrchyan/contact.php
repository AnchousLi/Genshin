<!DOCTYPE html>
<html>
<head>
    <title>contact</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
     <br>
<p class="contact">For questions or suggestions,write your details and we will contact you</p>
<br>

<div class="contact">
    <form method="post">
    <label  for="name">Full Name</label>
<input type="text" name="name" id="name" placeholder="Name">
<br>
<br>
<label for="email">Email Address</label>
<input type="email" name="email" id="email" placeholder="Email">
<br>
<br>
<label for="subject">Phone</label>
<input type="text" name="phone" id="phone" placeholder="Phone">
<input type="submit" name="send">
</form>
<br>
<p class="contact">Or visit us</p>
<p class="contact">We will wait for you</p>
<br>
</div>
<iframe class="iframe"  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d26792.10009758613!2d130.60291171025895!3d32.9242676605088!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3540581cbf255473%3A0xc1f116a9f0bd4fc!2sKonoha%2C%20Gyokuto%2C%20Tamana%20District%2C%20Kumamoto%20869-0303%2C%20Japan!5e0!3m2!1sen!2sam!4v1706809204635!5m2!1sen!2sam&quot; width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
<div class="hder">
    <div class="logo"> <img class="img" src="https://upload.wikimedia.org/wikipedia/ru/thumb/5/5d/Genshin_Impact_logo.svg/1024px-Genshin_Impact_logo.svg.png?20231028060936    "></div>
   
    <ul>
                <li><a href="html.php">Home</a> </li>
                <li><a href="monshtad.php">Monshtad</a> </li>
                <li><a href="li%20ue.php">Li Yue</a></li>
                <li><a href="inadzuma.php">Inadzuma</a> </li>
                <li><a href="sumeru.php">Sumeru</a> </li>
                <li><a href="fontine.php"> Fontein</a></li>
                <li><a href="contact.php">Contact</a></li>
				<li><a href="admin/index.php">Admin</a></li>
				<li><a href="products.php">Products</a></li>
            </ul>
</div>


</body>
</html>